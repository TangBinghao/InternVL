=======
Credits
=======

* `Mehdi Cherti <https://github.com/mehdidc>`_
* `Romain Beaumont <https://github.com/rom1504>`_
